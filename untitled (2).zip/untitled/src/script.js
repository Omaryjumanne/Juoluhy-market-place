document.getElementById('register-form').addEventListener('submit', function (e) {

    e.preventDefault();

    const name = document.getElementById('name').value;

    const email = document.getElementById('email').value;

    const password = document.getElementById('password').value;

    if (!name || !email || !password) {

        alert('Tafadhali jaza taarifa zote.');

        return;

    }

    alert('Umefanikiwa kujisajili!');

});

document.getElementById('add-product-form').addEventListener('submit', function (e) {

    e.preventDefault();

    const productName = document.getElementById('product-name').value;

    const productPrice = document.getElementById('product-price').value;

    const productDescription = document.getElementById('product-description').value;

    if (!productName || !productPrice || !productDescription) {

        alert('Tafadhali jaza taarifa zote za bidhaa.');

        return;

    }

    alert('Bidhaa yako imeongezwa kwa mafanikio!');

});

document.getElementById('search-bar').addEventListener('input', function (e) {

    let searchTerm = e.target.value.toLowerCase();

    console.log("Tafuta: " + searchTerm);

    // Filter products based on search term

});

document.getElementById('category-filter').addEventListener('change', function (e) {

    let selectedCategory = e.target.value;

    console.log("Kategoria iliyochaguliwa: " + selectedCategory);

    // Filter products based on selected category

});

document.querySelectorAll('.favorite-btn').forEach(function (btn) {

    btn.addEventListener('click', function () {

        alert('Bidhaa imewekwa kwenye orodha ya pendekezo!');

    });

});